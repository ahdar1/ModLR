#' ModLR: Information-Theoretic Moderation Analysis
#'
#' The ModLR package implements an information-theoretic framework for moderation analysis
#' using multi-model inference based on Akaike's Information Criterion (AIC and AICc).
#'
#' It enables researchers to compare alternative moderation models and reduces the risk
#' of spurious moderation effects arising from nonlinear relationships.
#'
#' The methodology is based on Daryanto (2019), which introduces an
#' information-theoretic approach to moderation analysis.
#'
#' @references
#' Daryanto, A. (2019). Avoiding spurious moderation effects:
#' An information-theoretic approach to moderation analysis.
#' Journal of Business Research, 103, 110–118.
#'
#' @keywords internal
"_PACKAGE"
