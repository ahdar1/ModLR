#' Johnson-Neyman Analysis
#'
#' Computes regions of significance for an interaction effect.
#'
#' @param object A fitted model (modlr or lm object)
#' @param alpha Significance level
#'
#' @return A list of Johnson-Neyman results
#' @examples
#' set.seed(123)
#' n <- 100
#' x <- rnorm(n)
#' z <- rnorm(n)
#' y <- x * z + rnorm(n)
#' data <- data.frame(x, z, y)
#'
#' obj <- moderated_regression(data, "x", "z", "y")
#' johnson_neyman(obj)
#' @export

johnson_neyman <- function(object, alpha = 0.05) {
  if (!inherits(object, "modlr")) stop("object must be of class modlr")

  if (object$type_moderator != "continuous") {
    stop("Johnson-Neyman technique is only for continuous moderators")
  }

  model <- object$model
  data <- object$data

  # Extract coefficients - using "int_term" instead of "interaction"
  b1 <- coef(model)["x_center"]
  b3 <- coef(model)["int_term"]
  se_b1 <- sqrt(vcov(model)["x_center", "x_center"])
  se_b3 <- sqrt(vcov(model)["int_term", "int_term"])
  cov_b1b3 <- vcov(model)["x_center", "int_term"]

  # Critical t-value
  t_crit <- qt(1 - alpha/2, df = df.residual(model))

  # Solve quadratic equation a*z^2 + b*z + c = 0
  a <- b3^2 - t_crit^2 * se_b3^2
  b <- 2 * (b1 * b3 - t_crit^2 * cov_b1b3)
  c <- b1^2 - t_crit^2 * se_b1^2

  # Find roots
  discriminant <- b^2 - 4 * a * c

  if (discriminant > 0 && a != 0) {
    z_lower <- (-b - sqrt(discriminant)) / (2 * a)
    z_upper <- (-b + sqrt(discriminant)) / (2 * a)

    # Sort roots
    z_values <- sort(c(z_lower, z_upper))

    # Convert back to original scale if centered
    if (object$center) {
      z_mean <- mean(data$z_center, na.rm = TRUE)
      z_sd <- sd(data$z_center, na.rm = TRUE)
      z_values_orig <- z_values * z_sd + z_mean
    } else {
      z_values_orig <- z_values
    }

    results <- data.frame(
      Region = c("Lower", "Upper"),
      z_centered = round(z_values, 3),
      z_original = round(z_values_orig, 3)
    )

    cat("
")
    cat("================================================================================
")
    cat("JOHNSON-NEYMAN REGIONS OF SIGNIFICANCE
")
    cat("================================================================================
")
    cat("Simple slope of x on y is significant when moderator (z) is:
")
    cat("Below", round(z_values_orig[1], 3), "
")
    cat("Above", round(z_values_orig[2], 3), "
")
    cat("Not significant between", round(z_values_orig[1], 3), "and", round(z_values_orig[2], 3), "
")
    cat("================================================================================

")



    return(results)
  } else {
    cat("
")
    cat("================================================================================
")
    cat("JOHNSON-NEYMAN REGIONS OF SIGNIFICANCE
")
    cat("================================================================================
")
    cat("No Johnson-Neyman regions found.
")
    cat("The simple slope of x on y is not significant at any value of the moderator (z).
")
    cat("================================================================================

")
    return(NULL)
  }
}

