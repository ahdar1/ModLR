#' @importFrom broom tidy
#' @importFrom ggplot2 ggplot aes geom_point geom_line labs theme
#' @importFrom stats AIC as.formula coef complete.cases df.residual lm na.omit predict pt qt sd vcov

NULL
