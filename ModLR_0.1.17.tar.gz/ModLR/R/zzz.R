utils::globalVariables(c(
  "x_center", "z_center", "z_level", ".pred"
))
