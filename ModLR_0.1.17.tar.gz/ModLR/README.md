# ModLR

**Information-Theoretic Approach for Moderation Analysis**

## 📦 Overview

`ModLR` implements an information-theoretic framework for moderation analysis using multi-model inference based on Akaike's Information Criterion (AIC and AICc).

The package enables researchers to compare alternative moderation models and reduces the risk of identifying spurious moderation effects arising from nonlinear relationships.

---

## 📖 Citation

If you use this package, please cite:

> Daryanto, A. (2019). *Avoiding spurious moderation effects: An information-theoretic approach to moderation analysis*. Journal of Business Research, 103, 110–118.

This package provides an implementation of the information-theoretic framework proposed in this study.

## ✨ Key Features

- ✅ Multi-model comparison using AIC / AICc
- ✅ Detection of spurious moderation due to nonlinearity
- ✅ Supports continuous and categorical moderators
- ✅ Simple slopes analysis
- ✅ Johnson–Neyman intervals
- ✅ Visualization of moderation effects

---

## 📥 Installation

```r
# Install from CRAN (after acceptance)
install.packages("ModLR")

# Load package
library(ModLR)
