## ----setup, include=FALSE-----------------------------------------------------
library(ModLR)

## ----eval=FALSE---------------------------------------------------------------
# 
# set.seed(123)
# 
# n <- 400
# 
# z <- sample(c(0, 1), n, replace = TRUE)
# x <- ifelse(z == 0, runif(n, 0.5, 6.5), runif(n, 3.5, 9.5))
# y <- (0.8 * x^2) + (30 * z) + rnorm(n, 0, 5)
# 
# ddat <- data.frame(x = x, y = y, z = z)
# 
# result <- moderated_regression(dat, iv = "x", moderator = "z", dv = "y")
# print(result)
# compare_models(result)

## ----eval=FALSE---------------------------------------------------------------
# simple_slopes(result)

## ----eval=FALSE---------------------------------------------------------------
# johnson_neyman(result)

## ----eval=FALSE---------------------------------------------------------------
# plot_moderation(result)

