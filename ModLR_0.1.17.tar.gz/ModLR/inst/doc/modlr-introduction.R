## ----setup, include=FALSE-----------------------------------------------------
library(ModLR)

## ----eval=FALSE---------------------------------------------------------------
# 
# set.seed(123)
# 
# n <- 100
# 
# # Generate predictors
# x <- rnorm(n)
# z <- 0.5 * x + sqrt(1 - 0.5^2) * rnorm(n)
# dat <- data.frame(x, z, y)
# 
# result <- moderated_regression(dat, iv = "x", moderator = "z", dv = "y")
# print(result)
# compare_models(result)

## ----eval=FALSE---------------------------------------------------------------
# simple_slopes(result)

## ----eval=FALSE---------------------------------------------------------------
# johnson_neyman(result)

## ----eval=FALSE---------------------------------------------------------------
# plot_moderation(result)

