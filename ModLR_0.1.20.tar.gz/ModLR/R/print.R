#' @export
#' @method print modlr
print.modlr <- function(x, ...) {

  cat("\nModerated Regression Model\n")
  cat("==========================\n\n")

  print(summary(x$model))

  if (!is.null(x$interaction_p)) {
    pval <- x$interaction_p

    pval_str <- if (is.na(pval)) {
      "NA"
    } else if (pval < 0.001) {
      "< 0.001"
    } else {
      format(round(pval, 4), nsmall = 4)
    }

    cat("\n---------------------------------\n")
    cat("Interaction p-value:", pval_str)

    if (!is.na(pval) && pval < 0.05) {
      cat(" (Significant)\n")
    } else {
      cat(" (Not significant)\n")
    }
    cat("\n")
  }
}
