
# True Moderation Plot - Shows interaction effect

plot_moderation <- function(object) {
  
  if (!inherits(object, "modlr")) {
    stop("object must be of class modlr")
  }
  
  if (!requireNamespace("ggplot2", quietly = TRUE)) {
    stop("ggplot2 package required")
  }
  
  data <- object$data
  type_mod <- object$type_moderator
  model <- object$model
  
  if (type_mod == "binary") {
    
    # For binary moderator: Create two separate lines
    # Get predicted values from the model (which includes interaction)
    data$.pred <- predict(model)
    
    # Create the plot with two separate lines for z=0 and z=1
    p <- ggplot2::ggplot(data, ggplot2::aes(x = x_center, y = .pred, 
                          color = as.factor(z_center), 
                          group = as.factor(z_center))) +
      ggplot2::stat_smooth(method = "lm", se = TRUE, size = 1.2) +
      ggplot2::labs(
        title = "Moderation Effect",
        subtitle = paste("Interaction p =", round(object$interaction_p, 4)),
        x = "Independent Variable (centered)",
        y = "Predicted Dependent Variable",
        color = "Moderator (z)"
      ) +
      ggplot2::theme_bw() +
      ggplot2::theme(legend.position = "bottom") +
      ggplot2::scale_color_manual(values = c("blue", "red"), 
                                 labels = c("z = 0", "z = 1"))
    
  } else {
    
    # For continuous moderator: Create three lines (low, medium, high)
    # Get coefficients
    b_x <- coef(model)["x_center"]
    b_z <- coef(model)["z_center"]
    b_xz <- coef(model)["int_term"]
    
    # Get moderator values at -1 SD, mean, +1 SD
    z_mean <- mean(data$z_center, na.rm = TRUE)
    z_sd <- sd(data$z_center, na.rm = TRUE)
    
    z_values <- c(z_mean - z_sd, z_mean, z_mean + z_sd)
    z_labels <- c("Low (-1 SD)", "Mean", "High (+1 SD)")
    z_colors <- c("blue", "green", "red")
    
    # Create prediction grid
    x_range <- seq(min(data$x_center), max(data$x_center), length.out = 100)
    
    # Create empty data frame for predictions
    pred_data <- data.frame()
    
    for (i in 1:3) {
      temp <- data.frame(
        x_center = x_range,
        z_center = z_values[i],
        z_level = z_labels[i]
      )
      # Calculate predicted values using the model coefficients
      temp$.pred <- b_x * temp$x_center + 
                    b_z * temp$z_center + 
                    b_xz * temp$x_center * temp$z_center +
                    coef(model)["(Intercept)"]
      pred_data <- rbind(pred_data, temp)
    }
    
    # Create plot
    p <- ggplot2::ggplot(pred_data, ggplot2::aes(x = x_center, y = .pred, 
                          color = z_level, group = z_level)) +
      ggplot2::geom_line(size = 1.2) +
      ggplot2::labs(
        title = "Moderation Effect (Continuous Moderator)",
        subtitle = paste("Interaction p =", round(object$interaction_p, 4)),
        x = "Independent Variable (centered)",
        y = "Predicted Dependent Variable",
        color = "Moderator Level"
      ) +
      ggplot2::theme_bw() +
      ggplot2::theme(legend.position = "bottom") +
      ggplot2::scale_color_manual(values = z_colors)
  }
  
  print(p)
  return(invisible(p))
}

