
moderated_regression <- function(data, iv, moderator, dv, covariates = NULL, center = TRUE, quadratic = FALSE, robust_se = FALSE) {
  
  detect_type <- function(x) {
    if (is.factor(x)) return("binary")
    unique_vals <- unique(na.omit(x))
    if (length(unique_vals) == 2 && all(sort(unique_vals) %in% c(0, 1))) {
      return("binary")
    } else if (length(unique_vals) <= 2) {
      return("binary")
    } else {
      return("continuous")
    }
  }
  
  if (!is.data.frame(data)) stop("data must be a data frame")
  
  required_vars <- c(iv, moderator, dv)
  if (!is.null(covariates)) required_vars <- c(required_vars, covariates)
  
  missing_vars <- required_vars[!required_vars %in% names(data)]
  if (length(missing_vars) > 0) stop("Missing variables: ", paste(missing_vars, collapse = ", "))
  
  data_clean <- data[complete.cases(data[, required_vars]), ]
  if (nrow(data_clean) < 10) stop("Insufficient observations")
  
  type_iv <- detect_type(data_clean[[iv]])
  type_moderator <- detect_type(data_clean[[moderator]])
  
  df <- data_clean
  
  if (center) {
    df$x_center <- scale(df[[iv]], center = TRUE, scale = FALSE)
    if (type_moderator == "continuous") {
      df$z_center <- scale(df[[moderator]], center = TRUE, scale = FALSE)
    } else {
      df$z_center <- as.numeric(df[[moderator]]) - mean(as.numeric(df[[moderator]]), na.rm = TRUE)
    }
    if (!is.null(covariates)) {
      for (cov in covariates) {
        if (is.numeric(df[[cov]])) {
          df[[paste0(cov, "_center")]] <- scale(df[[cov]], center = TRUE, scale = FALSE)
        } else {
          df[[paste0(cov, "_center")]] <- df[[cov]]
        }
      }
    }
  } else {
    df$x_center <- df[[iv]]
    df$z_center <- if(type_moderator == "binary") as.numeric(df[[moderator]]) else df[[moderator]]
    if (!is.null(covariates)) {
      for (cov in covariates) {
        df[[paste0(cov, "_center")]] <- df[[cov]]
      }
    }
  }
  
  # RENAME interaction to int_term to avoid conflict with R function
  df$int_term <- df$x_center * df$z_center
  
  if (!is.null(covariates)) {
    cov_terms <- paste0(paste0(covariates, "_center"), collapse = " + ")
    formula_base <- as.formula(paste(dv, "~", cov_terms, "+ x_center + z_center + int_term"))
  } else {
    formula_base <- as.formula(paste(dv, "~ x_center + z_center + int_term"))
  }
  
  if (quadratic) {
    df$x_sq <- df$x_center^2
    df$z_sq <- df$z_center^2
    if (type_iv != "binary" && type_moderator != "binary") {
      if (!is.null(covariates)) {
        formula_quad <- as.formula(paste(dv, "~", cov_terms, "+ x_center + z_center + int_term + x_sq + z_sq"))
      } else {
        formula_quad <- as.formula(paste(dv, "~ x_center + z_center + int_term + x_sq + z_sq"))
      }
    } else {
      formula_quad <- formula_base
    }
  } else {
    formula_quad <- formula_base
  }
  
  model <- lm(formula_quad, data = df)
  
  result <- list(
    model = model,
    summary = summary(model),
    coefficients = broom::tidy(model),
    type_iv = type_iv,
    type_moderator = type_moderator,
    interaction_p = coef(summary(model))["int_term", "Pr(>|t|)"],
    covariates = covariates,
    center = center,
    quadratic = quadratic,
    robust_se = robust_se,
    call = match.call(),
    data = df
  )
  
  class(result) <- "modlr"
  return(result)
}

