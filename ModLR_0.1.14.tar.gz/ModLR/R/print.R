
print.modlr <- function(x, ...) {
  cat("\nModerated Regression Results\n")
  cat("============================\n\n")
  cat("Interaction p-value:", round(x$interaction_p, 4))
  if (x$interaction_p < 0.05) cat(" (Significant)\n") else cat(" (Not significant)\n")
  cat("\n")
  print(x$summary)
}

