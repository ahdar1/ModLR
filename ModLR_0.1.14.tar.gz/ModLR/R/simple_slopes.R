
simple_slopes <- function(object, values = NULL) {
  if (!inherits(object, "modlr")) stop("object must be of class modlr")
  
  model <- object$model
  data <- object$data
  type_mod <- object$type_moderator
  
  if (!"int_term" %in% names(coef(model))) stop("No interaction term found")
  
  if (type_mod == "binary") {
    slope_0 <- coef(model)["x_center"]
    slope_1 <- coef(model)["x_center"] + coef(model)["int_term"]
    var_0 <- vcov(model)["x_center", "x_center"]
    var_1 <- var_0 + vcov(model)["int_term", "int_term"] + 2 * vcov(model)["x_center", "int_term"]
    se_0 <- sqrt(var_0)
    se_1 <- sqrt(var_1)
    t_0 <- slope_0 / se_0
    t_1 <- slope_1 / se_1
    df_res <- df.residual(model)
    p_0 <- 2 * pt(abs(t_0), df_res, lower.tail = FALSE)
    p_1 <- 2 * pt(abs(t_1), df_res, lower.tail = FALSE)
    results <- data.frame(Moderator = c("0", "1"), Slope = round(c(slope_0, slope_1), 3), SE = round(c(se_0, se_1), 3), t = round(c(t_0, t_1), 3), p_value = round(c(p_0, p_1), 4))
  } else {
    if (is.null(values)) {
      z_mean <- mean(data$z_center, na.rm = TRUE)
      z_sd <- sd(data$z_center, na.rm = TRUE)
      values <- c(z_mean - z_sd, z_mean, z_mean + z_sd)
      labels <- c("M - 1 SD", "M (Mean)", "M + 1 SD")
    } else {
      labels <- paste("z =", round(values, 3))
    }
    results <- data.frame(Moderator_Level = labels, Moderator_Value = round(values, 3), Slope = NA, SE = NA, t = NA, p_value = NA)
    for (i in seq_along(values)) {
      slope <- coef(model)["x_center"] + coef(model)["int_term"] * values[i]
      var_slope <- vcov(model)["x_center", "x_center"] + values[i]^2 * vcov(model)["int_term", "int_term"] + 2 * values[i] * vcov(model)["x_center", "int_term"]
      se_slope <- sqrt(var_slope)
      t_slope <- slope / se_slope
      p_slope <- 2 * pt(abs(t_slope), df.residual(model), lower.tail = FALSE)
      results$Slope[i] <- round(slope, 3)
      results$SE[i] <- round(se_slope, 3)
      results$t[i] <- round(t_slope, 3)
      results$p_value[i] <- round(p_slope, 4)
    }
  }
  return(results)
}

