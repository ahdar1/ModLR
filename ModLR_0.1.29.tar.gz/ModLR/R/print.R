#' @export
#' @method print modlr
print.modlr <- function(x, ...) {

  message("\nModerated Regression Model\n")
  message("==========================\n\n")

  print(summary(x$model))

  if (!is.null(x$interaction_p)) {
    pval <- x$interaction_p

    pval_str <- if (is.na(pval)) {
      "NA"
    } else if (pval < 0.001) {
      "< 0.001"
    } else {
      format(round(pval, 4), nsmall = 4)
    }

    message("\n---------------------------------\n")
    message("Interaction p-value:", pval_str)

    if (!is.na(pval) && pval < 0.05) {
      message(" (Significant)\n")
    } else {
      message(" (Not significant)\n")
    }
    message("\n")
  }
}
