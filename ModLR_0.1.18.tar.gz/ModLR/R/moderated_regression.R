#' Moderated Regression Model
#'
#' Fits a moderated regression model with optional extensions.
#'
#' @param data A data frame
#' @param dv Dependent variable
#' @param iv Independent variable
#' @param moderator Moderator variable
#' @param covariates Optional covariates
#' @param center Logical; whether to center variables
#' @param quadratic Logical; include quadratic terms
#' @param robust_se Logical; use HC3 robust standard errors
#'
#' @return A fitted model object
#' @importFrom stats lm coef vcov update
#' @importFrom sandwich vcovHC
#' @importFrom lmtest coeftest
#'
#' @export

moderated_regression <- function(data, iv, moderator, dv,
                                 covariates = NULL,
                                 center = TRUE,
                                 quadratic = FALSE,
                                 robust_se = FALSE) {

  detect_type <- function(x) {
    if (is.factor(x)) return("binary")
    unique_vals <- unique(na.omit(x))
    if (length(unique_vals) <= 2) return("binary")
    return("continuous")
  }

  if (!is.data.frame(data)) stop("data must be a data frame")

  required_vars <- c(iv, moderator, dv)
  if (!is.null(covariates)) required_vars <- c(required_vars, covariates)

  missing_vars <- required_vars[!required_vars %in% names(data)]
  if (length(missing_vars) > 0) {
    stop("Missing variables: ", paste(missing_vars, collapse = ", "))
  }

  data_clean <- data[complete.cases(data[, required_vars]), ]
  if (nrow(data_clean) < 10) stop("Insufficient observations")

  type_iv <- detect_type(data_clean[[iv]])
  type_moderator <- detect_type(data_clean[[moderator]])

  df <- data_clean

  # Centering
  if (center) {
    df$x_center <- scale(df[[iv]], center = TRUE, scale = FALSE)
    df$z_center <- scale(df[[moderator]], center = TRUE, scale = FALSE)
  } else {
    df$x_center <- df[[iv]]
    df$z_center <- df[[moderator]]
  }

  # Interaction
  df$int_term <- df$x_center * df$z_center

  # Covariates
  if (!is.null(covariates)) {
    for (cov in covariates) {
      df[[paste0(cov, "_center")]] <-
        if (center && is.numeric(df[[cov]])) {
          scale(df[[cov]], center = TRUE, scale = FALSE)
        } else {
          df[[cov]]
        }
    }

    cov_terms <- paste0(covariates, "_center", collapse = " + ")
    formula_base <- as.formula(
      paste(dv, "~", cov_terms, "+ x_center + z_center + int_term")
    )
  } else {
    formula_base <- as.formula(
      paste(dv, "~ x_center + z_center + int_term")
    )
  }

  # Quadratic
  if (quadratic && type_iv == "continuous" && type_moderator == "continuous") {
    df$x_sq <- df$x_center^2
    df$z_sq <- df$z_center^2
    formula_final <- update(formula_base, . ~ . + x_sq + z_sq)
  } else {
    formula_final <- formula_base
  }

  model <- lm(formula_final, data = df)

  coef_summary <- summary(model)$coefficients

  interaction_p <- if ("int_term" %in% rownames(coef_summary)) {
    coef_summary["int_term", "Pr(>|t|)"]
  } else {
    NA_real_
  }

  if (robust_se) {
    vc <- sandwich::vcovHC(model, type = "HC3")
    coef_table <- lmtest::coeftest(model, vc)
  } else {
    vc <- vcov(model)
    coef_table <- coef_summary
  }

  result <- list(
    model = model,
    vcov = vc,
    coef_table = coef_table,
    interaction_p = interaction_p,
    type_iv = type_iv,
    type_moderator = type_moderator,
    covariates = covariates,
    center = center,
    quadratic = quadratic,
    robust_se = robust_se,
    iv = iv,
    moderator = moderator,
    dv = dv,
    data = df,
    call = match.call()
  )

  class(result) <- "modlr"
  return(result)
}
